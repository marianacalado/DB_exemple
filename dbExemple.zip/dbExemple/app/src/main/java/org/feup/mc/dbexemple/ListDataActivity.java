package org.feup.mc.dbexemple;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class ListDataActivity extends AppCompatActivity {
    dataHelper helper;
    private ListView list;
    private Button btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_activity);
        list = findViewById(R.id.listView);
        helper = new dataHelper(this);


        populateListView();

        btn2 = findViewById(R.id.salir);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListDataActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
    private void populateListView(){
        //get data and append to a list
        Cursor data = helper.getAll();
        ArrayList<String> listdata = new ArrayList<>();
        while(data.moveToNext()){
            //get the value from the database in column 1 then ass it ro the arrayList
            listdata.add(data.getString(1));
        }
        //create the List adapter and set the adapter
        ListAdapter adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listdata);
        list.setAdapter(adapter);
    }

}